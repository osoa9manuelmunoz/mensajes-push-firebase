// routes.js
const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, FCMToken, Message,PushNotificationResult } = require('./models');
const admin = require('./firebase');
const path = require('path');
const authenticateToken = require('./authMiddleware');
const { Op } = require('sequelize');

const router = express.Router();
console.log(admin.appCheck().app.name);

const secretKey = 'your_jwt_secret';
const tokenExpiration = '7d';  // Configuración del token JWT para que expire en 7 días

// Crear cuenta de usuario
router.post('/register', async (req, res) => {
    const { email, password, fullName, phoneNumber, position, fcmToken } = req.body;
    if (!req.files || !req.files.photo) {
        return res.status(400).json({ error: 'Photo is required' });
    }

    const photo = req.files.photo;
    const photoName = `${Date.now()}_${photo.name}`;
    const photoPath = path.join(__dirname, 'uploads', photoName);

    try {
        photo.mv(photoPath, async (err) => {
            if (err) return res.status(500).json({ error: 'Error uploading photo' });

            const hashedPassword = await bcrypt.hash(password, 10);
            const user = await User.create({
                email, password: hashedPassword, photo: photoName, fullName, phoneNumber, position
            });
            await FCMToken.create({ token: fcmToken, UserEmail: email });

            const token = jwt.sign({ email }, secretKey, { expiresIn: tokenExpiration });
            res.json({ token });
        });
    } catch (error) {
        res.status(500).json({ error: 'Error creating user' });
    }
});

// Login de usuario
router.post('/login', async (req, res) => {
    const { email, password, fcmToken } = req.body;
    try {
        const user = await User.findOne({ where: { email } });
        if (!user) return res.status(400).json({ error: 'Invalid email or password' });

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) return res.status(400).json({ error: 'Invalid email or password' });

        // Eliminar la contraseña del objeto de usuario antes de enviar la respuesta
        const userWithoutPassword = { ...user.toJSON(), password: undefined };

        const existingToken = await FCMToken.findOne({ where: { token: fcmToken, UserEmail: email } });
        if (!existingToken) {
            await FCMToken.create({ token: fcmToken, UserEmail: email });
        }

        const token = jwt.sign({ email }, secretKey, { expiresIn: tokenExpiration });
        res.json({ token, user: userWithoutPassword });
    } catch (error) {
        res.status(500).json({ error: 'Error logging in' });
    }
});

// Enviar mensaje
router.post('/message', authenticateToken, async (req, res) => {
    const { title, body, senderEmail, recipientEmail } = req.body;
    try {
        const recipient = await User.findOne({ where: { email: recipientEmail }, include: FCMToken });
        if (!recipient) return res.status(404).json({ error: 'Recipient not found' });

        const message = await Message.create({
            title,
            body,
            senderEmail,
            recipientEmail
        });

        const notificationResults = [];
        for (const tokenObj of recipient.FCMTokens) {
            const messageNotification = {
                notification: {
                    title,
                    body
                },
                data: {
                    title,
                    body,
                    senderEmail
                },
                token: tokenObj.token
            };

            try {
                const response = await admin.messaging().send(messageNotification);
                notificationResults.push({
                    messageId: message.id,
                    token: tokenObj.token,
                    firebaseResponse: response
                });
            } catch (sendError) {
                console.error(`Error sending message to token ${tokenObj.token}:`, sendError);
                notificationResults.push({
                    messageId: message.id,
                    token: tokenObj.token,
                    firebaseResponse: sendError.message
                });
            }
        }

        await PushNotificationResult.bulkCreate(notificationResults);

        res.json({ success: true });
    } catch (error) {
        console.error('Error sending message:', error);
        res.status(500).json({ error: 'Error sending message' });
    }
});



// Obtener todos los usuarios
router.get('/users', authenticateToken, async (req, res) => {
    try {
        const users = await User.findAll({
            attributes: ['email', 'fullName', 'phoneNumber', 'position', 'photo']
        });

        if (users.length === 0) {
            return res.status(404).json({ error: 'No users found' });
        }

        res.json(users);
    } catch (error) {
        console.error('Error retrieving users:', error);
        res.status(500).json({ error: 'Error retrieving users' });
    }
});


// Obtener todos los mensajes entre un usuario y su contacto
router.get('/messages', authenticateToken, async (req, res) => {
    const { userEmail, contactEmail } = req.query;
    try {
        const messages = await Message.findAll({
            where: {
                [Op.or]: [
                    { senderEmail: userEmail, recipientEmail: contactEmail },
                    { senderEmail: contactEmail, recipientEmail: userEmail }
                ]
            },
        });
        res.json(messages);
    } catch (error) {
        res.status(500).json({ error: 'Error retrieving messages' });
    }
});

module.exports = router;
