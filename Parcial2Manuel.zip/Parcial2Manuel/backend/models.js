const { Sequelize, DataTypes } = require('sequelize');
const sequelize = new Sequelize({
    dialect: 'sqlite',
    storage: 'database.sqlite'
    
});

// Modelo de Usuario
const User = sequelize.define('User', {
    email: {
        type: DataTypes.STRING,
        primaryKey: true,
    },
    password: DataTypes.STRING,
    photo: DataTypes.STRING,
    fullName: DataTypes.STRING,
    phoneNumber: DataTypes.STRING,
    position: DataTypes.STRING,
});

// Modelo de Token FCM
const FCMToken = sequelize.define('FCMToken', {
    token: {
        type: DataTypes.STRING,
        primaryKey: true,
    },
    UserEmail: {
        type: DataTypes.STRING,
        references: {
            model: User,
            key: 'email',
        },
    },
});

// Modelo de Mensaje
const Message = sequelize.define('Message', {
    title: DataTypes.STRING,
    body: DataTypes.STRING,
    senderEmail: {
        type: DataTypes.STRING,
        references: {
            model: User,
            key: 'email',
        },
    },
    recipientEmail: {
        type: DataTypes.STRING,
        references: {
            model: User,
            key: 'email',
        },
    },
});

// Modelo de Resultados de Notificaciones Push
const PushNotificationResult = sequelize.define('PushNotificationResult', {
    messageId: {
        type: DataTypes.INTEGER,
        references: {
            model: Message,
            key: 'id',
        },
    },
    token: DataTypes.STRING,
    firebaseResponse: DataTypes.STRING,
});

User.hasMany(FCMToken, { foreignKey: 'UserEmail' });
User.hasMany(Message, { foreignKey: 'senderEmail' });
User.hasMany(Message, { foreignKey: 'recipientEmail' });
Message.hasMany(PushNotificationResult, { foreignKey: 'messageId' });

// Sincronización de los modelos con la base de datos
sequelize.sync();


module.exports = { User, FCMToken, Message, PushNotificationResult, sequelize };
