// app.js
const express = require('express');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const { sequelize } = require('./models');
const routes = require('./routes');

const app = express();
const PORT = 80;

app.use(bodyParser.json());
app.use(fileUpload());
app.use('/uploads', express.static('uploads'));
app.use('/api', routes);

sequelize.sync().then(() => {
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
});
