import 'package:examen_2/classes/message.dart';
import 'package:examen_2/classes/registered_user.dart';
import 'package:flutter/material.dart';

class MensajeDisplay extends StatelessWidget {
  final Message message;
  final RegisteredUser userChat;
  const MensajeDisplay(
      {super.key, required this.message, required this.userChat});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 15, horizontal: 25),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: userChat.email == message.recipientEmail
            ? Colors.green
            : Colors.white,
        borderRadius: BorderRadius.circular(5),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            offset: Offset(0, 2),
            blurRadius: 10.0,
            spreadRadius: 1.0,
          ),
        ],
      ),
      child: Text(
        message.body ?? "Body",
        style: TextStyle(
            fontSize: 20,
            color: userChat.email == message.recipientEmail
                ? Colors.white
                : Colors.black),
      ),
    );
  }
}
