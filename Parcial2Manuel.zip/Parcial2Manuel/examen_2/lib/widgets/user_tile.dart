import 'package:examen_2/classes/registered_user.dart';
import 'package:examen_2/config/config.dart';
import 'package:flutter/material.dart';

class UserTile extends StatelessWidget {
  final RegisteredUser user;

  const UserTile({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => Navigator.pushNamed(context, "perfil", arguments: user),
      child: Container(
        margin: const EdgeInsets.all(15),
        padding: const EdgeInsets.all(10),
        width: double.infinity,
        height: 125,
        decoration: BoxDecoration(color: Colors.white, boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 5,
            blurRadius: 7,
            offset: const Offset(0, 3), // changes position of shadow
          ),
        ]),
        child: Row(
          children: [
            //FOTO DE PERFIL DEL USUARIO
            Container(
              width: 100,
              height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage("$serverAddress/uploads/${user.photo}",
                      scale: 1),
                ),
              ),
            ),

            //INFORMACIÓN DE PERFIL DEL USUARIO
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    maxLines: 2,
                    user.fullName ?? "Usuario",
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 20),
                  ),
                  Text(
                    maxLines: 2,
                    user.email ?? "myinbox@email.com",
                    style: const TextStyle(
                        fontWeight: FontWeight.w500, fontSize: 18),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
