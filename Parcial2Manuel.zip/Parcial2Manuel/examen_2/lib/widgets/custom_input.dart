import 'package:flutter/material.dart';

class CustomInput extends StatelessWidget {
  final String label;
  final Icon icon;
  final bool isPassword;
  final TextEditingController controller;
  final Widget? suffixIcon;
  const CustomInput(
      {super.key,
      required this.label,
      required this.icon,
      required this.isPassword,
      required this.controller,
      this.suffixIcon});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.all(15),
      child: TextFormField(
        maxLength: 255,
        controller: controller,
        obscureText: isPassword,
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          prefixIcon: icon,
          suffixIcon: suffixIcon,
          labelText: label,
        ),
      ),
    );
  }
}
