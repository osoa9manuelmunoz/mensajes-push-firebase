import 'package:dio/dio.dart';
import 'package:examen_2/config/config.dart';
import 'package:firebase_messaging/firebase_messaging.dart';

Future<bool> registerUser({
  required String email,
  required String password,
  required String fullName,
  required String phoneNumber,
  required String position,
  required String photoPath,
}) async {
  final dio = Dio();
  const url =
      '$serverAddress/api/register'; // Cambia esto a la URL de tu servidor
  final fcmToken = await FirebaseMessaging.instance.getToken();
  FormData formData = FormData.fromMap({
    'email': email,
    'password': password,
    'fullName': fullName,
    'phoneNumber': phoneNumber,
    'position': position,
    'fcmToken': fcmToken,
    'photo': await MultipartFile.fromFile(photoPath,
        filename: photoPath.split('/').last),
  });

  try {
    final response = await dio.post(url, data: formData);
    if (response.statusCode == 200) {
      // Registro exitoso
      return true;
    } else {
      // Error en el registro
      return false;
    }
  } catch (_) {
    return false;
  }
}
