import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:examen_2/classes/message.dart';
import 'package:examen_2/classes/user_data.dart';
import 'package:examen_2/config/config.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

Future<List<Message>> cargarMensajes(String recipient) async {
  final Dio dio = Dio();
  const FlutterSecureStorage storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  final String? userObject = await storage.read(key: "user");
  final UserData userData = UserData.fromJson(jsonDecode(userObject!));
  final token = await storage.read(key: "token") ?? "";

  try {
    final response = await dio.get(
        "$serverAddress/api/messages?userEmail=${userData.email}&contactEmail=$recipient",
        options: Options(headers: {"Authorization": "Bearer $token"}));
    final List<Message> mensajes = [];
    for (var e in (response.data as List<dynamic>)) {
      mensajes.add(Message.fromJson(e));
    }
    return mensajes.reversed.toList();
  } catch (_) {
    return [];
  }
}
