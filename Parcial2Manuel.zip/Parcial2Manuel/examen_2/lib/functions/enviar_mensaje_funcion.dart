import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:examen_2/classes/user_data.dart';
import 'package:examen_2/config/config.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

Future<bool> enviarMensaje(String recipient, String body) async {
  final Dio dio = Dio();
  const FlutterSecureStorage storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  final String? userObject = await storage.read(key: "user");
  final UserData userData = UserData.fromJson(jsonDecode(userObject!));
  final token = await storage.read(key: "token") ?? "";

  try {
    await dio.post("$serverAddress/api/message",
        data: {
          "title": userData.fullName,
          "body": body,
          "senderEmail": userData.email,
          "recipientEmail": recipient
        },
        options: Options(headers: {"Authorization": "Bearer $token"}));
    return true;
  } catch (_) {
    return false;
  }
}
