import 'dart:convert';

import 'package:examen_2/classes/user_data.dart';
import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

Future<Map<String, dynamic>> inicioApp() async {
  await Future.delayed(Durations.long2);
  const FlutterSecureStorage storage = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  final String? sessionActive = await storage.read(key: "token");
  final String? userObject = await storage.read(key: "user");
  final UserData userData = UserData.fromJson(jsonDecode(userObject ?? "{}"));

  return {
    "navigate": sessionActive != null ? "app" : "login",
    "user": userData
  };
}
