import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:examen_2/classes/user_data.dart';
import 'package:examen_2/config/config.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

Future<Map<String, dynamic>> login(String email, String password) async {
  final Dio dio = Dio();
  final fcmToken = await FirebaseMessaging.instance.getToken();

  try {
    final response = await dio.post("$serverAddress/api/login",
        data: {"email": email, "password": password, "fcmToken": fcmToken});

    const FlutterSecureStorage storage = FlutterSecureStorage(
        aOptions: AndroidOptions(encryptedSharedPreferences: true));

    storage.write(key: "token", value: response.data["token"]);
    storage.write(key: "user", value: jsonEncode(response.data["user"]));

    return {"logged": true, "user": UserData.fromJson(response.data["user"])};
  } catch (_) {
    return {"logged": false};
  }
}
