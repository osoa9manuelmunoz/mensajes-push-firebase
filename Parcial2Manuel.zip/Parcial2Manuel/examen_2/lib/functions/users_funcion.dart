import 'package:dio/dio.dart';
import 'package:examen_2/classes/registered_user.dart';
import 'package:examen_2/config/config.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

Future<List<RegisteredUser>> getUsers(String userEmail) async {
  final Dio dio = Dio();

  try {
    const FlutterSecureStorage storage = FlutterSecureStorage(
        aOptions: AndroidOptions(encryptedSharedPreferences: true));

    final token = await storage.read(key: "token") ?? "";

    final response = await dio.get("$serverAddress/api/users",
        options: Options(headers: {"Authorization": "Bearer $token"}));

    final List<RegisteredUser> users = [];
    for (var e in (response.data as List<dynamic>)) {
      if (e["email"] == userEmail) {
        continue;
      }
      users.add(RegisteredUser.fromJson(e));
    }
    return users;
  } catch (_) {
    return [];
  }
}
