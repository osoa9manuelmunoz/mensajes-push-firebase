import 'package:flutter_secure_storage/flutter_secure_storage.dart';

Future<void> logout() async {
  const FlutterSecureStorage storage = FlutterSecureStorage(
      aOptions: AndroidOptions(encryptedSharedPreferences: true));
  await storage.deleteAll();
}
