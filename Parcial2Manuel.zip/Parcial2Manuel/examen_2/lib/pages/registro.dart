import 'package:examen_2/functions/registro_funcion.dart';
import 'package:examen_2/widgets/custom_input.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';

class RegistroPage extends StatelessWidget {
  const RegistroPage({super.key});

  @override
  Widget build(BuildContext context) {
    //CONTROLADORES DE LOS INPUTS
    final nombre = TextEditingController();
    final numero = TextEditingController();
    final rol = TextEditingController();
    final correo = TextEditingController();
    final contra = TextEditingController();
    late String photoPath;

    return Scaffold(
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 50),
              //DECORACION DE INICIO DE SESIÓN
              Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey[400]!,
                          offset: const Offset(4.0, 4.0),
                          blurRadius: 10.0,
                          spreadRadius: 2.0,
                        ),
                      ]),
                  child: IconButton(
                    onPressed: () async {
                      FilePickerResult? result = await FilePicker.platform
                          .pickFiles(
                              allowMultiple: false, type: FileType.image);
                      if (result != null) {
                        photoPath = result.files.single.path!;
                      }
                    },
                    icon: Icon(
                      Icons.person_add,
                      color: Colors.purple[400],
                      size: 165,
                    ),
                  )),
              const SizedBox(height: 50),

              //INPUT DE DATOS DEL USUARIO
              CustomInput(
                  label: "Nombre",
                  icon: const Icon(Icons.text_fields),
                  isPassword: false,
                  controller: nombre),
              CustomInput(
                  label: "Numero",
                  icon: const Icon(Icons.phone),
                  isPassword: false,
                  controller: numero),
              CustomInput(
                  label: "Posición",
                  icon: const Icon(Icons.email),
                  isPassword: false,
                  controller: rol),
              CustomInput(
                  label: "Correo",
                  icon: const Icon(Icons.email),
                  isPassword: false,
                  controller: correo),
              CustomInput(
                  label: "Contraseña",
                  icon: const Icon(Icons.password),
                  isPassword: true,
                  controller: contra),
              const SizedBox(height: 50),

              //BOTÓN DE INICIAR SESIÓN
              ElevatedButton(
                style: ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(Colors.purple[50])),
                child: const Text("Registrarme",
                    style:
                        TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                onPressed: () {
                  registerUser(
                          email: correo.text,
                          password: contra.text,
                          fullName: nombre.text,
                          phoneNumber: numero.text,
                          position: rol.text,
                          photoPath: photoPath)
                      .then((value) {
                    if (value) {
                      Navigator.pop(context);
                    }
                  });
                },
              ),
              const SizedBox(height: 50),

              //BOTÓN DE REGISTRO
              ElevatedButton(
                style: ButtonStyle(
                    backgroundColor: WidgetStatePropertyAll(Colors.purple[50])),
                child: const Text("Iniciar Sesión",
                    style:
                        TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
