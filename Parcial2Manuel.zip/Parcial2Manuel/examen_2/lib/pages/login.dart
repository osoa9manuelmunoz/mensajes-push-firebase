import 'package:examen_2/functions/login_funcion.dart';
import 'package:examen_2/widgets/custom_input.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    //CONTROLADORES DE LOS INPUTS
    final correo = TextEditingController();
    final contra = TextEditingController();

    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            //DECORACION DE INICIO DE SESIÓN
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey[400]!,
                      offset: const Offset(4.0, 4.0),
                      blurRadius: 10.0,
                      spreadRadius: 2.0,
                    ),
                  ]),
              child: Icon(
                Icons.person,
                color: Colors.purple[400],
                size: 175,
              ),
            ),
            const SizedBox(height: 50),

            //INPUT DE DATOS DEL USUARIO
            CustomInput(
                label: "Correo",
                icon: const Icon(Icons.email),
                isPassword: false,
                controller: correo),
            CustomInput(
                label: "Contraseña",
                icon: const Icon(Icons.password),
                isPassword: true,
                controller: contra),
            const SizedBox(height: 50),

            //BOTÓN DE INICIAR SESIÓN
            ElevatedButton(
              style: ButtonStyle(
                  backgroundColor: WidgetStatePropertyAll(Colors.purple[50])),
              child: const Text("Iniciar Sesión",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              onPressed: () {
                login(correo.text, contra.text).then(
                  (value) {
                    if (value["logged"]) {
                      Navigator.pushNamedAndRemoveUntil(
                          context, "app", (route) => false,
                          arguments: value);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Center(
                        child: Text("Error al iniciar sesión"),
                      )));
                    }
                  },
                );
              },
            ),
            const SizedBox(height: 50),

            //BOTÓN DE REGISTRO
            ElevatedButton(
              style: ButtonStyle(
                  backgroundColor: WidgetStatePropertyAll(Colors.purple[50])),
              child: const Text("Registrarme",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              onPressed: () => Navigator.pushNamed(context, "registro"),
            ),
          ],
        ),
      ),
    );
  }
}
