import 'package:examen_2/classes/user_data.dart';
import 'package:examen_2/config/config.dart';
import 'package:examen_2/functions/logout_funcion.dart';
import 'package:examen_2/functions/users_funcion.dart';
import 'package:examen_2/widgets/user_tile.dart';
import 'package:flutter/material.dart';

class AppPage extends StatelessWidget {
  const AppPage({super.key});

  @override
  Widget build(BuildContext context) {
    final UserData userData = (ModalRoute.of(context)!.settings.arguments
        as Map<String, dynamic>)["user"] as UserData;
    return Scaffold(
      //APPBAR PARA VER EL USUARIO LOGGEADO, CERRAR SESIÓN Y PERFIL
      appBar: AppBar(
        toolbarHeight: 75,
        backgroundColor: Colors.purple[50],
        title: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(
                      "$serverAddress/uploads/${userData.photo}",
                      scale: 1),
                ),
              ),
            ),
            const SizedBox(width: 15),
            Text(
              userData.fullName ?? "XD",
              style: TextStyle(
                  color: Colors.purple[400],
                  fontWeight: FontWeight.w600,
                  fontSize: 25),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: () {
              logout().then((_) => Navigator.pushNamedAndRemoveUntil(
                    context,
                    "login",
                    (_) => false,
                  ));
            },
            icon: Icon(
              Icons.logout,
              color: Colors.purple[400],
            ),
          ),
        ],
      ),
      body: FutureBuilder(
        future: getUsers(userData.email!),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return ListView.separated(
                itemBuilder: (context, index) {
                  return UserTile(user: snapshot.data![index]);
                },
                separatorBuilder: (context, index) =>
                    const Divider(thickness: 2),
                itemCount: snapshot.data!.length);
          }

          return const Center(child: CircularProgressIndicator());
        },
      ),
    );
  }
}
