import 'dart:async';

import 'package:examen_2/classes/message.dart';
import 'package:examen_2/classes/registered_user.dart';
import 'package:examen_2/functions/enviar_mensaje_funcion.dart';
import 'package:examen_2/functions/mensajes_funcion.dart';
import 'package:examen_2/widgets/custom_input.dart';
import 'package:examen_2/widgets/mensaje_display.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';

class MensajesPage extends StatefulWidget {
  const MensajesPage({super.key});

  @override
  State<MensajesPage> createState() => _MensajesPageState();
}

class _MensajesPageState extends State<MensajesPage> {
  final messageInputController = TextEditingController();
  final StreamController<Message> sendMessage = StreamController<Message>();

  @override
  void dispose() {
    sendMessage.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final userChat =
        ModalRoute.of(context)!.settings.arguments as RegisteredUser;
    final Stream<Message> sendMessageListener = sendMessage.stream;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 75,
        backgroundColor: Colors.purple[50],
        centerTitle: true,
        title: Text(
          "Chat de ${userChat.fullName ?? "Usuario"}",
          style: TextStyle(
              color: Colors.purple[400],
              fontWeight: FontWeight.w600,
              fontSize: 25),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: _ChatLoader(
              userChat: userChat,
              sendMessageListener: sendMessageListener,
            ),
          ),
          CustomInput(
            label: "Enviar Mensaje",
            icon: const Icon(Icons.message),
            isPassword: false,
            controller: messageInputController,
            suffixIcon: IconButton(
                onPressed: () {
                  if (messageInputController.text.isNotEmpty) {
                    enviarMensaje(userChat.email!, messageInputController.text);
                    sendMessage.add(
                      Message(
                        body: messageInputController.text,
                        recipientEmail: userChat.email,
                      ),
                    );
                    messageInputController.clear();
                  }
                },
                icon: const Icon(Icons.send)),
          )
        ],
      ),
    );
  }
}

class _ChatLoader extends StatelessWidget {
  final RegisteredUser userChat;
  final Stream<Message> sendMessageListener;
  const _ChatLoader(
      {required this.userChat, required this.sendMessageListener});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: cargarMensajes(userChat.email!),
      builder: (context, snapshot) {
        if (snapshot.hasData) {
          return _ChatContent(
            userChat: userChat,
            sendMessageListener: sendMessageListener,
            chatMessages: snapshot.data!,
          );
        }
        return const Center(child: CircularProgressIndicator());
      },
    );
  }
}

class _ChatContent extends StatefulWidget {
  final RegisteredUser userChat;
  final Stream<Message> sendMessageListener;
  final List<Message> chatMessages;
  const _ChatContent(
      {required this.userChat,
      required this.sendMessageListener,
      required this.chatMessages});

  @override
  State<_ChatContent> createState() => __ChatContentState();
}

class __ChatContentState extends State<_ChatContent> {
  @override
  void initState() {
    widget.sendMessageListener.listen(
      (newMessage) {
        setState(() => widget.chatMessages.insert(0, newMessage));
      },
    );
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => FirebaseMessaging.onMessage.listen(
        (message) {
          if (message.data["senderEmail"] != message.data["recipientEmail"]) {
            setState(
              () => widget.chatMessages.insert(
                0,
                Message(
                  body: message.data["body"],
                  recipientEmail: message.data["recipientEmail"],
                ),
              ),
            );
          }
        },
      ),
    );
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      reverse: true,
      itemCount: widget.chatMessages.length,
      itemBuilder: (context, index) => MensajeDisplay(
          message: widget.chatMessages[index], userChat: widget.userChat),
    );
  }
}
