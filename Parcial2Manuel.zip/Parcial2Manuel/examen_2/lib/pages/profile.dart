import 'package:examen_2/classes/registered_user.dart';
import 'package:examen_2/config/config.dart';
import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final RegisteredUser userData =
        ModalRoute.of(context)!.settings.arguments as RegisteredUser;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 75,
        backgroundColor: Colors.purple[50],
        centerTitle: true,
        title: Text(
          "Perfil de ${userData.fullName ?? "Usuario"}",
          style: TextStyle(
              color: Colors.purple[400],
              fontWeight: FontWeight.w600,
              fontSize: 25),
        ),
      ),
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          children: [
            //FOTO DE PERFIL DEL USUARIO
            Container(
              margin: const EdgeInsets.only(top: 50, bottom: 25),
              width: 175,
              height: 175,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(
                      "$serverAddress/uploads/${userData.photo}",
                      scale: 1),
                ),
              ),
            ),

            //NOMBRE DEL USUARIO
            Text(
              maxLines: 2,
              userData.fullName ?? "Usuario",
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 30),
            ),

            //CORREO DEL USUARIO
            Text(
              textAlign: TextAlign.center,
              maxLines: 2,
              "Correo:\n"
              "${userData.email ?? "myinbox@email.com"}",
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
            ),

            //TELEFONO DEL USUARIO
            Text(
              textAlign: TextAlign.center,
              maxLines: 2,
              "Teléfono:\n"
              "+${userData.phoneNumber ?? "+3434314413"}",
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
            ),

            //CARGO DEL USUARIO
            Text(
              textAlign: TextAlign.center,
              maxLines: 2,
              "Profesión:\n"
              "${userData.position ?? "Only a User :D"}",
              style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
            ),
            const SizedBox(height: 50),

            //ENVIAR MENSAJE DIRECTO
            ElevatedButton(
              style: ButtonStyle(
                  backgroundColor: WidgetStatePropertyAll(Colors.purple[50])),
              child: const Text("Bandeja de Mensajes",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)),
              onPressed: () =>
                  Navigator.pushNamed(context, "mensajes", arguments: userData),
            ),
          ],
        ),
      ),
    );
  }
}
