import 'package:examen_2/functions/inicio_funcion.dart';
import 'package:flutter/material.dart';

class InicioPage extends StatelessWidget {
  const InicioPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: inicioApp(),
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            Future.delayed(Durations.long2).then(
              (_) => Navigator.pushNamedAndRemoveUntil(
                  context, snapshot.data!["navigate"], (route) => false,
                  arguments: snapshot.data),
            );
          }
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}
