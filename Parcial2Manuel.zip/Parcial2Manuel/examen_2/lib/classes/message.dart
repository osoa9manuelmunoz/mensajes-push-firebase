class Message {
  int? id;
  String? title;
  String? body;
  String? senderEmail;
  String? recipientEmail;
  String? createdAt;
  String? updatedAt;

  Message(
      {this.id,
      this.title,
      this.body,
      this.senderEmail,
      this.recipientEmail,
      this.createdAt,
      this.updatedAt});

  Message.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    body = json['body'];
    senderEmail = json['senderEmail'];
    recipientEmail = json['recipientEmail'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title;
    data['body'] = body;
    data['senderEmail'] = senderEmail;
    data['recipientEmail'] = recipientEmail;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}
