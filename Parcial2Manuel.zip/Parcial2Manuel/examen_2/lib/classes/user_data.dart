class UserData {
  String? email;
  String? photo;
  String? fullName;
  String? phoneNumber;
  String? position;
  String? createdAt;
  String? updatedAt;

  UserData(
      {this.email,
      this.photo,
      this.fullName,
      this.phoneNumber,
      this.position,
      this.createdAt,
      this.updatedAt});

  UserData.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    photo = json['photo'];
    fullName = json['fullName'];
    phoneNumber = json['phoneNumber'];
    position = json['position'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['photo'] = photo;
    data['fullName'] = fullName;
    data['phoneNumber'] = phoneNumber;
    data['position'] = position;
    data['createdAt'] = createdAt;
    data['updatedAt'] = updatedAt;
    return data;
  }
}
