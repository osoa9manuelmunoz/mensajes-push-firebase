class RegisteredUser {
  String? email;
  String? fullName;
  String? phoneNumber;
  String? position;
  String? photo;

  RegisteredUser(
      {this.email, this.fullName, this.phoneNumber, this.position, this.photo});

  RegisteredUser.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    fullName = json['fullName'];
    phoneNumber = json['phoneNumber'];
    position = json['position'];
    photo = json['photo'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['email'] = email;
    data['fullName'] = fullName;
    data['phoneNumber'] = phoneNumber;
    data['position'] = position;
    data['photo'] = photo;
    return data;
  }
}
